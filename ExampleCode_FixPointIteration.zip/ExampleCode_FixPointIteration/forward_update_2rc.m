function [v1_seq, v2_seq, SoC_seq, I_bat_seq] = forward_update_2rc(P_fc, P_dem, SoC0, batt, dt, v1_0, v2_0)

N = numel(P_dem);
v1_seq   = zeros(1, N+1);
v2_seq   = zeros(1, N+1);
SoC_seq  = zeros(1, N+1);
I_bat_seq= zeros(1, N);

v1 = v1_0;  v2 = v2_0;  SoC = SoC0;

v1_seq(1)=v1; v2_seq(1)=v2; SoC_seq(1)=SoC;

R0pk = batt.eqRes;                        % pack R0 = cellR0 * n_s / n_p
a1   = exp(-dt/(batt.cellR1*batt.cellC1));  b1 = batt.cellR1*(1 - a1);
a2   = exp(-dt/(batt.cellR2*batt.cellC2));  b2 = batt.cellR2*(1 - a2);

for k = 1:N
    P_bat = P_dem(k) - P_fc(k);

    % 等效端电压（本步以 v1,v2 固定）：Ueff = Uoc_pack(SoC) - n_s*(v1+v2)
    Ueff  = batt.ocVolt(SoC) - batt.n_s*(v1 + v2);

    % 用二次闭式解反解 I_bat：P = I*(Ueff - R0*I)
    if R0pk < 1e-12
        I_bat = P_bat / max(Ueff, 1e-6);
    else
        disc  = max(Ueff.^2 - 4*R0pk*P_bat, 0);
        I1    = (Ueff - sqrt(disc)) / (2*R0pk);
        I2    = (Ueff + sqrt(disc)) / (2*R0pk);
        e1    = abs(P_bat - I1*(Ueff - R0pk*I1));
        e2    = abs(P_bat - I2*(Ueff - R0pk*I2));
        I_bat = I1; if e2<e1, I_bat = I2; end
    end
    I_bat_seq(k) = I_bat;

    % 2-RC 离散更新（cell 级）
    I_cell = I_bat / batt.n_p;
    v1 = a1*v1 + b1*I_cell;
    v2 = a2*v2 + b2*I_cell;
    SoC= SoC - dt * I_cell / batt.Q_cell;

    v1_seq(k+1)=v1; v2_seq(k+1)=v2; SoC_seq(k+1)=SoC;
end
end
