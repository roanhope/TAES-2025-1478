function [time, x0, xf, f, L, F, u_bound, g, u_nom, b_nom] = shevProblemSetup2( dynaprog, demand, gen, batt)


x0 = [0.6; 0];
% Final state
%   must be a column vector
xf = 0.6;

time = (1:length(demand))';
motPwr = demand;

motPwr = griddedInterpolant(time, motPwr);
    
%% State dynamics
%   must be a column vector function of x,u,t
SOC_lo = 0.4;
SOC_up = 0.8;


battPwr = @(u,t)  motPwr(t) - u .* gen.maxPwr;

% Subtract the dynamics of the two RCs in the form of a "virtual OCV bias": Ueff = Uoc_pack - n_s*(v1+v2)
idx       = @(tt) max(1, min(numel(time), round(tt)));  % t→（time = (1:N)'）
ocVoltEff = @(soc,tt) batt.ocVolt(soc) - batt.n_s * ( batt.v1_seq(idx(tt)) + batt.v2_seq(idx(tt)) );

% The original quadratic closed-form solution remains unchanged, but ocVoltEff is used instead of ocVolt
battCurr = @(x,u,t) ( ocVoltEff(x(1),t) - sqrt( ocVoltEff(x(1),t).^2 - 4.*batt.eqRes.*battPwr(u,t) ) ) ./ ( 2*batt.eqRes );


battCurr = memoize( battCurr );
f_soc = @(x,u,t) - battCurr(x,u,t) ./ ( batt.nomCap * 3600 );
if ~dynaprog
    f = f_soc;
else
    battCurr = @(x,u,t) ( batt.ocVolt(x(1)) - sqrt( batt.ocVolt(x(1)).^2 - 4 .* batt.eqRes .* battPwr(u,t) ) ) ./ ( 2*batt.eqRes );
    f_soc = @(x,u,t) - battCurr(x,u,t) ./ ( batt.nomCap * 3600 );
    f = f_soc;
end


L = @(x,u,t) gen.fuelConsumption(u.* gen.basePwr) *gen.Xfc/1000*4;

% Terminal cost
%   must be a scalar function of x,t
F = @(x, t) 1e1*(x(1) - xf(1)).^2; % balancing term

%% Constraints 
% Control bounds u lower bound, u upper bound
u_bound = [0, 1];

% Mixed state-control inequality constraints g(x,u,t) <= 0
% SOC Window
a1 = 100;
a2 = a1;
g{1} = @(x,u,t) f_soc(x,u,t) + a1 * ( x(1) - SOC_up );
g{2} = @(x,u,t) - f_soc(x,u,t) + a2 * ( SOC_lo - x(1) );

%% Nominal multipliers
b_nom = - 1; 
u_nom = @(t) full( 0.06 .* ones(size(t)) );

end

