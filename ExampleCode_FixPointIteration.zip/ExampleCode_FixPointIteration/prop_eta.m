
function eta_prop = prop_eta(T_req, V_inf, rho_air, D_inch, lookup_mat)


    if nargin < 4 || isempty(D_inch),   D_inch = 24; end
    if nargin < 5 || isempty(lookup_mat), lookup_mat = 'APC24x12E_lookup.mat'; end

    if ~(isscalar(T_req) && T_req>0) || ~(isscalar(V_inf) && V_inf>=0) || ~(isscalar(rho_air) && rho_air>0)
        eta_prop = NaN;  return;
    end

    % —— 持久化加载（仅第一次 load）——
    persistent pp_CT pp_CP pp_PE Jmin Jmax
    if isempty(pp_CT)
        S = load(lookup_mat, 'pp_CT','pp_CP','pp_PE','Jmin','Jmax');
        pp_CT = S.pp_CT; pp_CP = S.pp_CP; pp_PE = S.pp_PE;
        Jmin  = S.Jmin;  Jmax  = S.Jmax;
    end

    D = D_inch * 0.0254;    % [m]

    % —— 以 J 为未知量反解 ——  T(J) = Ct(J)*rho*(V/(J*D))^2 * D^4
    clampJ = @(J) min(max(J, Jmin), Jmax);
    CT_ofJ = @(J) max(0,   ppval(pp_CT, clampJ(J)));
    CP_ofJ = @(J) max(eps, ppval(pp_CP, clampJ(J)));
    PE_ofJ = @(J) max(0, min(1, ppval(pp_PE, clampJ(J))));

    if V_inf == 0
        J_star = max(0, Jmin);    % 静止工况：J=0
    else
        funT = @(J) CT_ofJ(J) .* rho_air .* ( (V_inf./(max(J,1e-8).*D)).^2 ) .* D.^4;
        obj  = @(J) ( funT(J) - T_req ).^2;

        % 优先 fminbnd；如无该函数或异常，退化为网格搜索
        try
            J_star = fminbnd(obj, max(Jmin,1e-4), Jmax);
        catch
            Jgrid = linspace(max(Jmin,1e-4), Jmax, 600);
            [~,k] = min(obj(Jgrid));  J_star = Jgrid(k);
        end
    end

    % —— 推进效率 ——  Pe(J) = Ct(J)*J / Cp(J)
    % 直接用预存的 Pe 样条（等价，也更稳）
    eta_prop = PE_ofJ(J_star);
end

