figure;
set(gcf, 'Units', 'centimeters', 'Position', [2, 2, 12, 8]); % 88mm x 90mm

tiledlayout(2, 1, 'Padding', 'compact', 'TileSpacing', 'compact');

%% soc**
nexttile;

plot(ts, x_dp_sol(:,1),'LineStyle',"-", 'Color','0.00,0.45,0.74', 'LineWidth', 1); % 蓝色，高度
ylabel('SoC', 'FontSize', 8, 'FontName', 'Times New Roman');
yticks([0.4 0.6 0.8])
ylim([0.3 0.9])
xlim([0 2150]);
grid on;
set(gca, 'FontSize', 8, 'FontName', 'Times New Roman', 'LineWidth', 1);
box on;

%% (Power kW)**
nexttile;
plot(ts, Pems/1000, 'LineStyle',"-", 'Color','0.00,0.45,0.74', 'LineWidth', 1); 
hold on;
Pfc_b = u_dp_sol*gen.maxPwr;
plot(ts, Pfc_b/1000,'LineStyle',"-", 'Color','0.85,0.33,0.10', 'LineWidth', 1); 
hold on;
plot(ts, (Pems - u_dp_sol*gen.maxPwr)/1000,'LineStyle',"-",  'Color','0.47,0.67,0.19', 'LineWidth', 1); 

xlim([0 2150]);
ylabel('Power (kW)', 'FontSize', 8, 'FontName', 'Times New Roman');
grid on;

leg=legend('{{\itP}_{d}}','{{\itP}_{fc}}','{{\itP}_{bat}}');
set(leg,'Box','off','FontSize',7,'Orientation','horizontal','Location','best');
leg.ItemTokenSize = [10,40];

ylim([-3 7])
yticks([-2  0 2 4])

set(gca, 'FontSize', 8, 'FontName', 'Times New Roman', 'LineWidth', 1);
box on;
xlabel({'Time (s)'}, 'FontSize', 8, 'FontName', 'Times New Roman');
grid on;
set(gca, 'FontSize', 8, 'FontName', 'Times New Roman', 'LineWidth', 1);
box on;

print(gcf, 'TwoStep.png', '-dpng', '-r300');