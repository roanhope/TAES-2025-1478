function [x_next, stage_cost, unfeas] = dp_model(x, u, w, f, L)


dt = w{2};
% %% 1) 解析状态 & 控制
SOC_prev   = x{1};    % 当前SOC
u_prev     = x{2};    % 上一时刻控制
u_now      = u{1};    % 当前时刻控制
%% 2) 动力学演化: 计算新的SOC
maxPwr = evalin('base','Pfc');  
fc_maxchange = 0.1 * maxPwr;
u_change =abs( u_now-u_prev).* maxPwr;
unfeas = ( u_change > fc_maxchange );


dxdt = f(x{1}, u{1}, w{1});
x_next{1} = x{1} + dxdt .* dt;
x_next{2} = u_now;

%% Cost
stage_cost = L(x{1}, u{1}, w{1}) .* dt;

end