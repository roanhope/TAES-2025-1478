function [T, alpha] = solveEquationsDynamic(rho, v, S_w, m, g, gamma, alpha_data, CL_data, CD_data)
    % solveEquationsDynamic dynamically solves for T and alpha with varying lift and drag coefficients.
    % Inputs:
    % rho - air density
    % v - velocity
    % S_w - wing area
    % m - aircraft mass
    % g - acceleration due to gravity
    % gamma - pitch angle (in radians)


    
    % Initial guess for fsolve
    initial_guess = [100, 5];  % Initial guesses for T and alpha
    
    % Set options for fsolve with 'levenberg-marquardt' algorithm
    options = optimoptions('fsolve', 'Display', 'none', 'Algorithm', 'levenberg-marquardt');
    
    % Define the system of equations with alpha-dependent lift and drag coefficients
    equations = @(x) equationsToSolve(x, rho, v, S_w, m, g, gamma, alpha_data, CL_data, CD_data);
    
    % Solve the equations using fsolve
    [solution, ~, exitflag] = fsolve(equations, initial_guess, options);
    
    % Check if the solution was found
    if exitflag <= 0
        error('solveEquationsDynamic:NoConvergence', 'fsolve did not converge to a solution');
    end
    
    % Assign the solution to output variables
    T = double(solution(1));
    alpha = double(solution(2));
end

function F = equationsToSolve(x, rho, v, S_w, m, g, gamma, alpha_data, CL_data, CD_data)
    % Extract T and alpha from the input array
    T = x(1);
    alpha = deg2rad(x(2));  % Convert alpha from degrees to radians
    
    % Calculate lift and drag coefficients dynamically
    C_L = lift_coefficient(rad2deg(alpha),alpha_data,CL_data);
    C_D = drag_coefficient(rad2deg(alpha),alpha_data,CD_data);
    
    % Define the system of equations
    eqn1 = 0.5 * rho * v^2 * C_L * S_w + T * sin(alpha) - m * g * cos(gamma);
    eqn2 = T * cos(alpha) - 0.5 * rho * v^2 * C_D * S_w - m * g * sin(gamma);
    
    % Return the equations to solve
    F = [eqn1; eqn2];
end

function C_L = lift_coefficient(alpha, alpha_data, CL_data)

    
    % Interpolate to find C_L at the given alpha
    C_L = interp1(alpha_data, CL_data, alpha, 'linear', 'extrap');
end

function C_D = drag_coefficient(alpha, alpha_data, CD_data)
    
    % Interpolate to find C_D at the given alpha
    C_D = interp1(alpha_data, CD_data, alpha, 'linear', 'extrap');
end
