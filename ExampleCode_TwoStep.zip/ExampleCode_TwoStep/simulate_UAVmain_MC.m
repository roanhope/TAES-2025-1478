% simulate_UAVmain_MC.m
function [T_MC,A_MC,P_org_MC,P_shaft_MC,P_ele_MC,Prop_eta_MC,Mot_eta_MC] = simulate_UAVmain_MC(m)



dt = 1;                % 时间步长 [s]
t_end = 2150;          % 总时间 [s]

sigma_u   = 2.4;        % [m/s] Dryden RMS (≈0.2*12 m/s for Beaufort‑6)
meanWind  = 0;          % [m/s] constant head(+)/tail(‑) wind; set 0 here
tau_w     = 5;          % [s] Dryden correlation time constant

S_w = 2.0;
t = 0:dt:t_end;        % 时间向量
N = length(t);

t_profile = [0 400 1000 1500 1700 1900 2150];         % 时间点
h_profile = [0 1000 1000 50 500 500 0];               % 高度[m]
v_profile = [19 25 25 20 22 22 19];                   % 速度[m/s]
% 插值生成连续时间对应的高度/速度
h_raw = interp1(t_profile, h_profile, t, 'linear');        % 平滑插值
v_g = interp1(t_profile, v_profile, t, 'linear');    % 平滑插值

tau = 2;                          % 时间常数 [秒]
sys_h = tf(1, [tau 1]);           % 一阶低通滤波器
h = lsim(sys_h, h_raw, t)';       % 模拟滤波后高度（即加延迟）

%h = h_raw;
rho = 1.225 * exp(-h/8500);  % 指数大气模型，简化版

dh_dt = [0 diff(h)/dt];      % 一阶差分近似（首项补0）

%% 4.5 Dryden 1‑D longitudinal wind (u) ----------------------------------
Gu        = tf(1,[tau_w 1]);       % magnitude 1 low‑pass
eta       = randn(1,N);
u_g       = sigma_u * lsim(Gu,eta,t)';   % stochastic component
u_wind    = meanWind + u_g;        % total head/tail wind (+ tailwind)

v_nominal     = max(v_g - u_wind,0.1); % avoid zero/divide issues

v_nominal    = v_g; %不要风
gamma = atan(dh_dt ./ v_nominal);    % 弧度

g = 9.81;        % 重力加速度 [m/s^2]

alpha_data = [-4, 0, 2, 4, 6, 8, 10, 12, 14, 15, 16];
CL_data =    [0.05, 0.38, 0.5, 0.65, 0.77, 0.85, 0.92, 1, 1.08, 1.11, 1.125];
CD_data =    [0.055, 0.05, 0.06, 0.075, 0.08, 0.105, 0.13, 0.155, 0.195, 0.21, 0.235];

n_MC = 1;             % 蒙特卡洛次数
%sigma_v = 0.5;           % 飞行速度标准差 [m/s]
%sigma_v = 1.5;
sigma_v = 0;

% 初始化输出矩阵
T_MC = NaN(n_MC, N);
A_MC = NaN(n_MC, N);
P_org_MC = NaN(n_MC, N);
P_shaft_MC = NaN(n_MC, N);   
P_ele_MC = NaN(n_MC, N);
Prop_eta_MC = NaN(n_MC, N);
Mot_eta_MC = NaN(n_MC, N);

for mc = 1:n_MC
    % 生成扰动后的速度剖面（正态分布扰动）
%     v_perturbed = v_nominal + sigma_v * randn(1, N);
%     v_perturbed = max(v_perturbed, 5); % 保证速度不为负
    v_perturbed = v_nominal;
    
    T_series = NaN(1, N);
    A_series = NaN(1, N);
    P_series_org = NaN(1, N);
    P_shaft = NaN(1, N); 
    P_ele = NaN(1, N);
    eta_prop_series = NaN(1, N);
    eta_mot_series = NaN(1, N);
    
    for i = 1:N
        try
            [T, A] = solveEquationsDynamic(rho(i), v_perturbed(i), S_w, m, g, gamma(i), alpha_data, CL_data, CD_data);
        catch
            T = NaN;
        end
        T_series(i) = T;
        A_series(i) = A;
        eta_prop_series(i) = prop_eta(T, v_perturbed(i), rho(i));
        P_series_org(i) = T * v_perturbed(i);
        P_shaft(i) = P_series_org(i)/eta_prop_series(i);
        eta_mot_series(i) = mot_eta(P_shaft(i));
        P_ele(i) = P_shaft(i)/eta_mot_series(i);

    end

    T_MC(mc, :) = T_series;
    A_MC(mc, :) = A_series;
    Prop_eta_MC(mc, :) = eta_prop_series;
    Mot_eta_MC(mc, :) = eta_mot_series;
    P_org_MC(mc, :) = P_series_org;
    P_shaft_MC(mc, :) = P_shaft;   
    P_ele_MC(mc, :) = P_ele;

end


end

